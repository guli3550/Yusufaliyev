# Yusufaliyev v0.8

Yusufaliyev — Uzbek voice assistant prototype.

## v0.8
- Foreground assistant service + persistent notification
- Uzbek TTS through the foreground service
- Voice input with `uz-UZ`
- Confirmation flow for camera, dialer and SMS actions
- AI fallback through backend
- Android command router

### Muhim
Android fon cheklovlari sabab mikrofonni cheksiz yashirin tinglashga urinmaydi. Foreground service foydalanuvchiga assistant faol ekanini ko‘rsatadi; ovozli kiritish foydalanuvchi tugmasi orqali ishga tushadi. Keyingi bosqichda haqiqiy offline wake-word engine qo‘shiladi.
