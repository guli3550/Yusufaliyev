package uz.yusufaliyev.app.commands

sealed class AssistantAction {
    data object OpenCamera : AssistantAction()
    data object OpenDialer : AssistantAction()
    data object OpenSms : AssistantAction()
    data object OpenWifi : AssistantAction()
    data object OpenBluetooth : AssistantAction()
    data object OpenSettings : AssistantAction()
    data object OpenBrowser : AssistantAction()
    data object OpenYoutube : AssistantAction()
    data class SearchWeb(val query: String) : AssistantAction()
    data object None : AssistantAction()
}

data class RoutedCommand(val action: AssistantAction, val confirmationRequired: Boolean = false, val reply: String)

object CommandRouter {
    fun route(text: String): RoutedCommand {
        val t = text.trim().lowercase()
        return when {
            t.contains("kamera") -> RoutedCommand(AssistantAction.OpenCamera, confirmationRequired = true, reply = "Kamerani ochaman.")
            t.contains("qo'ng'iroq") || t.contains("telefon") || t.contains("dialer") -> RoutedCommand(AssistantAction.OpenDialer, confirmationRequired = true, reply = "Telefonni ochaman.")
            t.contains("sms") || t.contains("xabar") -> RoutedCommand(AssistantAction.OpenSms, confirmationRequired = true, reply = "SMS oynasini ochaman.")
            t.contains("wi-fi") || t.contains("wifi") -> RoutedCommand(AssistantAction.OpenWifi, reply = "Wi-Fi sozlamalarini ochaman.")
            t.contains("bluetooth") -> RoutedCommand(AssistantAction.OpenBluetooth, reply = "Bluetooth sozlamalarini ochaman.")
            t.contains("sozlam") || t.contains("settings") -> RoutedCommand(AssistantAction.OpenSettings, reply = "Sozlamalarni ochaman.")
            t.contains("youtube") -> RoutedCommand(AssistantAction.OpenYoutube, reply = "YouTube'ni ochaman.")
            t.contains("brauzer") || t.contains("browser") || t == "internet" -> RoutedCommand(AssistantAction.OpenBrowser, reply = "Brauzerni ochaman.")
            t.startsWith("qidir ") || t.startsWith("google ") -> {
                val q = t.substringAfter(' ').trim()
                RoutedCommand(AssistantAction.SearchWeb(q), reply = "Internetdan qidiraman: $q")
            }
            else -> RoutedCommand(AssistantAction.None, reply = "Buni AI suhbat sifatida qayta ishlayman.")
        }
    }
}
