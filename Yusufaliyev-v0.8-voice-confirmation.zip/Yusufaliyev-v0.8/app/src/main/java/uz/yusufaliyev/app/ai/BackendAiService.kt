package uz.yusufaliyev.app.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class BackendAiService(private val baseUrl: String = "http://10.0.2.2:3000") {
    private val client = OkHttpClient()
    fun ask(text: String, history: List<Pair<String, String>>): String {
        val messages = org.json.JSONArray()
        history.takeLast(12).forEach { (role, content) -> messages.put(JSONObject().put("role", role).put("content", content)) }
        messages.put(JSONObject().put("role", "user").put("content", text))
        val body = JSONObject().put("message", text).put("history", messages).toString()
        val request = Request.Builder().url("$baseUrl/chat").post(body.toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Backend HTTP ${response.code}")
            val raw = response.body?.string().orEmpty()
            return JSONObject(raw).optString("reply", raw)
        }
    }
}
