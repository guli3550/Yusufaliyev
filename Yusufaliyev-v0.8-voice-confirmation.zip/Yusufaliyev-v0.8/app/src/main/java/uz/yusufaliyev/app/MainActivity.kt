package uz.yusufaliyev.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.yusufaliyev.app.ai.BackendAiService
import uz.yusufaliyev.app.commands.*

class MainActivity : ComponentActivity() {
    private val ai = BackendAiService()
    private val history = mutableListOf<Pair<String, String>>()
    private var pendingAction: AssistantAction? = null
    private var onResult: ((String) -> Unit)? = null

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return@registerForActivityResult
        handle(text)
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        startAssistantService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestAssistantPermissions()
        setContent { App() }
    }

    private fun requestAssistantPermissions() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.RECORD_AUDIO)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startAssistantService() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startAssistantService() {
        val intent = Intent(this, AssistantForegroundService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Yusufaliyevni tinglayapman…")
        }
        speech.launch(i)
    }

    private fun handle(text: String) {
        onResult?.invoke("Siz: $text")
        lifecycleScope.launch {
            val routed = CommandRouter.route(text)
            when (val action = routed.action) {
                AssistantAction.None -> {
                    val reply = withContext(Dispatchers.IO) { ai.ask(text, history) }
                    history += "user" to text
                    history += "assistant" to reply
                    respond(reply)
                }
                else -> {
                    if (routed.confirmationRequired) {
                        pendingAction = action
                        respond("Tasdiqlaysizmi? ${routed.reply} Ha yoki yo‘q deng.")
                    } else {
                        execute(action)
                        respond(routed.reply)
                    }
                }
            }
        }
    }

    private fun respond(text: String) {
        onResult?.invoke("Yusufaliyev: $text")
        val i = Intent(this, AssistantForegroundService::class.java).apply {
            action = AssistantForegroundService.ACTION_SPEAK
            putExtra(AssistantForegroundService.EXTRA_TEXT, text)
        }
        ContextCompat.startForegroundService(this, i)
    }

    private fun execute(action: AssistantAction) {
        val intent = when (action) {
            AssistantAction.OpenCamera -> Intent("android.media.action.IMAGE_CAPTURE")
            AssistantAction.OpenDialer -> Intent(Intent.ACTION_DIAL)
            AssistantAction.OpenSms -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            AssistantAction.OpenWifi -> Intent(Settings.ACTION_WIFI_SETTINGS)
            AssistantAction.OpenBluetooth -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            AssistantAction.OpenSettings -> Intent(Settings.ACTION_SETTINGS)
            AssistantAction.OpenBrowser -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            AssistantAction.OpenYoutube -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            is AssistantAction.SearchWeb -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(action.query)}"))
            AssistantAction.None -> return
        }
        runCatching { startActivity(intent) }
    }

    private fun confirm(text: String) {
        val t = text.trim().lowercase()
        val action = pendingAction ?: return
        when {
            t == "ha" || t == "xa" || t == "tasdiq" || t.contains("tasdiqlayman") -> {
                pendingAction = null
                execute(action)
                respond("Bajarildi.")
            }
            t == "yo'q" || t == "yo‘q" || t == "yoq" || t.contains("bekor") -> {
                pendingAction = null
                respond("Bekor qilindi.")
            }
        }
    }

    @Composable
    fun App() {
        var output by remember { mutableStateOf("Yusufaliyev tayyor.") }
        onResult = { output = it }
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Yusufaliyev", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(16.dp))
                Text(output)
                Spacer(Modifier.height(24.dp))
                Button(onClick = { listen() }) { Text("🎙 Yusufaliyev") }
                Spacer(Modifier.height(12.dp))
                Text("Foreground assistant faol", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
